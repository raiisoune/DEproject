from pymongo import MongoClient

from pprint import pprint
client = MongoClient(
host="127.0.0.1",
port=27017,
username="admin", # Nom d'utilisateur de l'administrateur MongoDB
password="pass", # Mot de passe de l'administrateur MongoDB
)
database_names = client.list_database_names()
pprint(database_names)
database = client.Airline_Flight_Status  # Nom de la base de données
collection_names = database.list_collection_names()
pprint(collection_names)

collection = database.flightstatus  # Nom de la collection

document = collection.find_one()    #trouver un document
pprint(document)
document_count = collection.count_documents({})
print("Nombre de documents dans la collection : ", document_count) #nombre de documents

Route = { "route": { "$regex": "los", "$options": "i" } } #trouver un vol qui passe par "los"
resultats = collection.find(Route)
for vol in resultats:
    print(vol)

projection = { "flightNumber": 1, "route": 1, "_id": 0 } #afficher que le numero de vol et la route qui passe par "los"
resultats = collection.find(Route, projection)
for vol in resultats:
    print("Numéro de vol:", vol["flightNumber"])
    print("Route:", vol["route"])
   
query = { "airline.code": "HV" } # Afficher airline dont le code est "HV"
projection = { "flightNumber": 1, "airline.name": 1, "_id": 0 }
airline_name = collection.find(query, projection)
for vol in airline_name:
    print("Numéro de vol:", vol["flightNumber"])
    print("Compagnie aérienne:", vol["airline"]["name"])
    print()
